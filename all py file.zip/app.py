import os
import cv2
from ultralytics import YOLO

# ==== CONFIGURATION ==== #
MODEL_PATH = r"C:\objYol\GlassNoGlass\best.pt"  # Change this to your trained model path
INPUT_FOLDER = r"C:\objYol\GlassNoGlass\Data\test_greyscale"  # Folder containing test images
OUTPUT_FOLDER = r"C:\objYol\GlassNoGlass\Data\output_imgs"  # Folder to save annotated images

# Create output folder if it does not exist
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# Load the trained YOLO model
model = YOLO(MODEL_PATH)

# Process each image in the input folder
for filename in os.listdir(INPUT_FOLDER):
    if filename.lower().endswith((".jpg", ".jpeg", ".png")):  # Supported formats
        image_path = os.path.join(INPUT_FOLDER, filename)
        output_path = os.path.join(OUTPUT_FOLDER, filename)

        # Run YOLO model on image
        results = model(image_path)

        # Draw bounding boxes on image
        for result in results:
            image = result.plot()  # Get annotated image

            # Save annotated image
            cv2.imwrite(output_path, image)
            print(f"Annotated: {filename} -> {output_path}")

print("✅ Auto-annotation completed! Check the output folder.")
